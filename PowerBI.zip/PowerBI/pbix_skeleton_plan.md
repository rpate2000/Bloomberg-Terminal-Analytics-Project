# Power BI PBIX Skeleton Plan: Bloomberg Terminal Project

## Data Model (Star Schema)
- Fact tables:
  - Market_Data (DateKey -> Date[Date], Ticker)
  - Portfolio_Holdings (DateKey -> Date[Date], Ticker)
- Dimension tables:
  - Date (DateKey, Date, Year, Month, Quarter, IsBusinessDay)
  - Tickers (Ticker, CompanyName (synthetic), Sector, Country)
  - Economic Indicators can be a dimension or fact depending on queries

## Relationships
- Date[Date] 1 --- * Market_Data[Date]
- Date[Date] 1 --- * Portfolio_Holdings[SnapshotDate]
- Tickers[Ticker] 1 --- * Market_Data[Ticker]
- Tickers[Ticker] 1 --- * Financials[Ticker]
- Tickers[Ticker] 1 --- * Portfolio_Holdings[Ticker]

## Pages & Visuals
1. Market Overview
   - KPI cards: Global Market Avg Return, VIX proxy (volatility), Top Gainers/Losers
   - World map (choropleth) by market performance (Country)
   - Sector heatmap (matrix/heat)
   - Table: Top 10 movers with sparkline
2. Company Fundamentals (single-ticker drillable)
   - Line charts: Revenue, Net Income, EPS (quarters)
   - Bar: Margin analysis & valuation multiples
   - Waterfall: Profit breakdown
3. Portfolio Tracker
   - Donut/Bar: Sector & Regional Exposure
   - Table: Holdings with Unrealized P/L, ROI
   - Time-series: Portfolio Value vs Benchmark
   - Metrics: Sharpe, CAGR, Max Drawdown (DAX)
4. Macro & Forex Monitor
   - Multi-row cards: GDP, Inflation, Interest Rate
   - Scatter: GDP vs Inflation (country selector)
   - FX volatility chart & currency pair selector
5. Dashboard (Executive)
   - Snapshot of key KPIs + Recommendation box (use Bookmarks)

## Performance & Modelling Recommendations
- Use Import mode for Market_Data and use aggregations for heavy date-range queries.
- Consider incremental refresh partitions (per month) for Market_Data and Forex_Data.
- Create calculated columns only when necessary; favour measures.
- Use summarized tables for reporting-level datasets (pre-aggregations).

## Bookmarks & Drillthrough
- Set up drillthrough from holdings to company fundamentals page.
- Bookmarks for "End of Day", "Last Month", "1-Year Trend" views.
